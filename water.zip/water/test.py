# print(int('1f', 16))


a = 255
a = bytes(a)
for temp in a:
    print(hex(temp))

print(a[0],a[1],a[2])
