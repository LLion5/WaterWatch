import port


port.port_to_data(str(6.9),str(2999),str(13.5))
port.port_to_data(str(6.8),str(2986),str(12.5))
port.port_to_data(str(6.8),str(2978),str(13.4))
